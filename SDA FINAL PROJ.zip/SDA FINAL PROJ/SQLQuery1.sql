create database Blood_Bank
--1Admin
create table [Admin]
(
Admin_Id int identity primary key,
Admin_Name varchar(100)
)
alter table Admin add Password varchar(6)
insert into Admin values ('Shahwaiz','1234')
insert into Admin values ('Abdul','4321')
insert into Admin values ('Sannia','1234')
select * from Admin

create table Hospital
(
Hospital_ID int identity primary key,
H_Name varchar(250),
H_address varchar(250),
H_City varchar(250),
H_Email varchar(255),
H_Website varchar(250)
)

create table Blood_Collection
(
BCollection_ID int identity primary key,
Blood_Group varchar(250),
Blood_Type varchar(250),
Quantity_ml int
)


create table Registration_staff_Donar
(
Admin_Id int,
Admin_Name varchar(250) ,
Donar_ID int ,
Reg_Date varchar(20),
primary key(Admin_Id,Donar_ID,Reg_Date),
)

create table Donar
(
Donar_ID int identity primary Key,
Hospital_ID int ,
foreign key (Hospital_ID) references Hospital(Hospital_ID),
D_Name varchar(250),
D_BloogGroup varchar (250),
D_BloodType varchar(250),
D_BloodQuantity varchar(500),
D_ContactNo varchar(11),
D_CNIC varchar(13),
D_city varchar(250),
[Date] varchar(250)
)


create table Donar_Hospital(
Donar_ID int ,
Hospital_ID int ,
[Date] varchar(250),
primary Key (Donar_ID,Hospital_ID,[Date]),
Blood_Group varchar(250),
Blood_Type varchar(250),
Quantity_ml int
)



create table Registration_staff_reciever
(
Admin_Name varchar(250),
Reciever_ID int ,
Reg_Date varchar(250),
primary key(Admin_Name,Reciever_ID,Reg_Date),
)

create table Reciever
(
Reciever_ID int identity primary Key,
Hospital_ID int ,
foreign key (Hospital_ID) references Hospital(Hospital_ID),
R_Name varchar(250),
R_BloogGroup varchar (250),
R_BloodType varchar(250),
R_ContactNo varchar(11),
R_CNIC varchar(13),
R_BloodQuantity varchar(500),
R_city varchar(250),
[Date] varchar(250)
)

create table Reciever_Blood
(
Reciever_ID int ,
BCollection_ID int ,
[Date] varchar(250),
primary key (Reciever_ID,BCollection_ID,[Date]),
Blood_Group varchar(250),
Blood_Type varchar(250),
Quantity_ml int
)

create table Reciever_Hospital(
Reciever_ID int ,
Hospital_ID int,
[Date] varchar(250),
primary Key (Reciever_ID,Hospital_ID,[Date]),
Blood_Group varchar(250),
Blood_Type varchar(250),
Quantity_ml int
)

create table Donar_Assign(
Reciever_ID int ,
Donar_ID int ,
[Date] varchar(250) ,
primary Key (Reciever_ID,Donar_ID,[Date]),
Blood_Group varchar(250),
Blood_Type varchar(250),
Quantity_ml int
)



create table DonorLog
(
DonorID int,
DName varchar(225),
DBloodgroup varchar(2),
DBloodtype varchar(1),
DContactNo varchar(11),
DCNIC varchar(13),
DCity varchar(225),
[DataofRegistraion] varchar(20),
Quantity int,
ActionPerformed varchar(500),
ActionDate datetime
)


create trigger trfAfterDonorInsert on Donar
after insert
as
declare @ID int,@Name varchar(225),@dbg varchar(2),@dbt varchar(1),@dcn varchar(11),@cnic varchar(13),@city varchar(500),@dor varchar(20),@quan int,@Action varchar(500);
select @ID=i.Donar_ID from inserted i;
select @Name=i.D_Name from inserted i;
select @dbg=i.D_BloogGroup from inserted i;
select @dbt=i.D_BloodType from inserted i;
select @dcn=i.D_ContactNo from inserted i;
select @cnic=i.D_CNIC from inserted i;
select @city=i.D_city from inserted i;
select @dor=i.Date from inserted i;
select @quan=i.D_BloodQuantity from inserted i;
set @Action='Data Inserted'
insert into DonorLog values(@ID,@Name,@dbg,@dbt,@dcn,@cnic,@city,@dor,@quan,@Action,GETDATE());

create trigger trfAfterDonorUpdate on Donar
after update
as
declare @ID int,@Name varchar(225),@dbg varchar(2),@dbt varchar(1),@dcn varchar(11),@cnic varchar(13),@city varchar(500),@dor varchar(20),@quan int,@Action varchar(500);
select @ID=i.Donar_ID from inserted i;
select @Name=i.D_Name from inserted i;
select @dbg=i.D_BloogGroup from inserted i;
select @dbt=i.D_BloodType from inserted i;
select @dcn=i.D_ContactNo from inserted i;
select @cnic=i.D_CNIC from inserted i;
select @city=i.D_city from inserted i;
select @dor=i.Date from inserted i;
select @quan=i.D_BloodQuantity from inserted i;
set @Action='Data Updated'
insert into DonorLog values(@ID,@Name,@dbg,@dbt,@dcn,@cnic,@city,@dor,@quan,@Action,GETDATE());


create trigger trfAfterDonorDelete on Donar
after delete
as
declare @ID int,@Name varchar(225),@dbg varchar(2),@dbt varchar(1),@dcn varchar(11),@cnic varchar(13),@city varchar(500),@dor varchar(20),@quan int,@Action varchar(500);
select @ID=i.Donar_ID from deleted i;
select @Name=i.D_Name from deleted i;
select @dbg=i.D_BloogGroup from deleted i;
select @dbt=i.D_BloodType from deleted i;
select @dcn=i.D_ContactNo from deleted i;
select @cnic=i.D_CNIC from deleted i;
select @city=i.D_city from deleted i;
select @dor=i.Date from deleted i;
select @quan=i.D_BloodQuantity from deleted i;
set @Action='Data Deleted'
insert into DonorLog values(@ID,@Name,@dbg,@dbt,@dcn,@cnic,@city,@dor,@quan,@Action,GETDATE());

create table ReceiverLog
(
ReceiverID int,
RName varchar(225),
RBloodgroup varchar(2),
RBloodtype varchar(1),
RContactNo varchar(11),
RCNIC varchar(13),
RCity varchar(225),
[DataofRegistraion] varchar(20),
Quantity int,
ActionPerformed varchar(500),
ActionDate datetime
)

create trigger trfAfterReceiverInsert on Reciever
after insert
as
declare @ID int,@Name varchar(225),@dbg varchar(2),@dbt varchar(1),@dcn varchar(11),@cnic varchar(13),@city varchar(500),@dor varchar(20),@quan int,@Action varchar(500);
select @ID=i.Reciever_ID from inserted i;
select @Name=i.R_Name from inserted i;
select @dbg=i.R_BloogGroup from inserted i;
select @dbt=i.R_BloodType from inserted i;
select @dcn=i.R_ContactNo from inserted i;
select @cnic=i.R_CNIC from inserted i;
select @city=i.R_city from inserted i;
select @dor=i.Date from inserted i;
select @quan=i.R_BloodQuantity from inserted i;
set @Action='Data Inserted'
insert into ReceiverLog values(@ID,@Name,@dbg,@dbt,@dcn,@cnic,@city,@dor,@quan,@Action,GETDATE());


create trigger trfAfterReceiverUpdate on Reciever
after update
as
declare @ID int,@Name varchar(225),@dbg varchar(2),@dbt varchar(1),@dcn varchar(11),@cnic varchar(13),@city varchar(500),@dor varchar(20),@quan int,@Action varchar(500);
select @ID=i.Reciever_ID from inserted i;
select @Name=i.R_Name from inserted i;
select @dbg=i.R_BloogGroup from inserted i;
select @dbt=i.R_BloodType from inserted i;
select @dcn=i.R_ContactNo from inserted i;
select @cnic=i.R_CNIC from inserted i;
select @city=i.R_city from inserted i;
select @dor=i.Date from inserted i;
select @quan=i.R_BloodQuantity from inserted i;
set @Action='Data Updated'
insert into ReceiverLog values(@ID,@Name,@dbg,@dbt,@dcn,@cnic,@city,@dor,@quan,@Action,GETDATE());


create trigger trfAfterReceiverDelete on Reciever
after delete
as
declare @ID int,@Name varchar(225),@dbg varchar(2),@dbt varchar(1),@dcn varchar(11),@cnic varchar(13),@city varchar(500),@dor varchar(20),@quan int,@Action varchar(500);
select @ID=i.Reciever_ID from deleted i;
select @Name=i.R_Name from deleted i;
select @dbg=i.R_BloogGroup from deleted i;
select @dbt=i.R_BloodType from deleted i;
select @dcn=i.R_ContactNo from deleted i;
select @cnic=i.R_CNIC from deleted i;
select @city=i.R_city from deleted i;
select @dor=i.Date from deleted i;
select @quan=i.R_BloodQuantity from deleted i;
set @Action='Data Deleted'
insert into ReceiverLog 
values(@ID,@Name,@dbg,@dbt,@dcn,@cnic,@city,@dor,@quan,@Action,GETDATE());
