﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class Hospitals : Form
    {
        Thread th;
        string name;
        public Hospitals(string name)
        {
            this.name = name;
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public Hospitals()
        {
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void viewhospitals_Click(object sender, EventArgs e)
        {
            this.Hide();
            new viewHospital(this.name).ShowDialog();
            this.Close();
        }
        private void openviewHospital()
        {
            Application.Run(new viewHospital());
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }
        private void opennewform()
        {
            Application.Run(new Dashboard());
        }

        private void viewdHospital_Click(object sender, EventArgs e)
        {
            this.Hide();
            new viewDHospital(name).ShowDialog();
            this.Close();
        }
        private void opendHospital()
        {
            Application.Run(new viewDHospital());
        }

        private void viewrHospital_Click(object sender, EventArgs e)
        {
            this.Hide();
            new viewRHospital(name).ShowDialog();
            this.Close();
        }
        private void openrHospital()
        {
            Application.Run(new viewRHospital());
        }

        private void Hospitals_Load(object sender, EventArgs e)
        {

        }
    }
}
