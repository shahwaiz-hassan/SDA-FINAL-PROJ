﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class MainPage : Form
    {
        Thread th;
        DatabaseHelper db;
        public MainPage()
        {
            db = new DatabaseHelper();
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void blurBack(object sender, PaintEventArgs e)
        {

        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string name = username.Text.ToString();
            string pass = password.Text.ToString();
            DataTable dt = db.Read("select * from Admin");
            int rows = dt.Rows.Count;
            string[] names = new string[rows - 1];
            string[] passwords = new string[rows - 1];
            for(int i = 0; i < rows - 1; i++)
            {
                names[i] = dt.Rows[i][1].ToString();
                passwords[i] = dt.Rows[i][2].ToString();
            }
            for(int i = 0; i < rows - 1; i++)
            {
                if (names[i] == name && passwords[i] == pass)
                {
                    this.Hide();
                    new Dashboard(name).ShowDialog();
                    this.Close();
                }
            }
            MessageBox.Show(" Incorrect username/password.\n\t   Try again!");
        }

        private void MainPage_Load(object sender, EventArgs e)
        {
            loginButton.BackColor = Color.FromArgb(70, 0, 0, 0);
            BlurBack.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
    }
}
