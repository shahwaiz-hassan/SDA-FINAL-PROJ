﻿using SDA_PROJ.Controllers;
using SDA_PROJ.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class AssignDonor : Form
    {
        DonorController dc;
        ReceiverController rc;
        DonorAssignController dac;
        string name;
        public AssignDonor(string name)
        {
            this.name = name;
            dc = new DonorController();
            rc = new ReceiverController();
            dac = new DonorAssignController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public AssignDonor()
        {
            dc = new DonorController();
            rc = new ReceiverController();
            dac = new DonorAssignController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }
        private void opennewform()
        {
            Application.Run(new Dashboard());
        }

        private void btnAssign_Click(object sender, EventArgs e)
        {
            AssignDonorModel obj = new AssignDonorModel();
            obj.DID = int.Parse(donorid.Text.ToString());
            obj.dbg = donorbloodgroup.Text.ToString();
            obj.dbt = donorbloodtype.Text.ToString();
            obj.RID = int.Parse(recieverid.Text.ToString());
            obj.rbg = receiverbloodgroup.Text.ToString();
            obj.rbt = receiverbloodtype.Text.ToString();
            obj.date = date.Text.ToString();
            dac.InsertData(obj);
            AssignDonor_Load(sender, e);
        }



        private void AssignDonor_Load(object sender, EventArgs e)
        {
            DataTable dtd= dc.getDonors();
            DataTable dtr = rc.getReceivers();
            int rowsd = dtd.Rows.Count;
            int rowsr = dtr.Rows.Count;
            int[] Did = new int[rowsd-1];
            int[] Rid = new int[rowsr - 1];
            string[] DBG = new string[rowsd - 1];
            string[] DBT = new string[rowsd - 1];
            string[] RBG = new string[rowsr - 1];
            string[] RBT = new string[rowsr - 1];
            for(int i = 0; i < rowsd - 1; i++)
            {
                Did[i] = int.Parse(dtd.Rows[i][0].ToString());
                DBG[i] = dtd.Rows[i][2].ToString();
                DBT[i] = dtd.Rows[i][3].ToString();
            }
            for (int i = 0; i < rowsr - 1; i++)
            {
                Rid[i] = int.Parse(dtr.Rows[i][0].ToString());
                RBG[i] = dtr.Rows[i][2].ToString();
                RBT[i] = dtr.Rows[i][3].ToString();
            }
            for (int i = 0; i < rowsd - 1; i++)
            {
                donorid.Items.Add(Did[i]);
                donorbloodgroup.Items.Add(DBG[i]);
                donorbloodtype.Items.Add(DBT[i]);
            }
            for (int i = 0; i < rowsr - 1; i++)
            {
                recieverid.Items.Add(Rid[i]);
                receiverbloodgroup.Items.Add(RBG[i]);
                receiverbloodtype.Items.Add(RBT[i]);
            }
            DataTable dt = dac.GetData();
            dataGridView1.DataSource = dt;

        }

        private void donorid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
