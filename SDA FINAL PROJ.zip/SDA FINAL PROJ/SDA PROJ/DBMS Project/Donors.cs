﻿using SDA_PROJ.Controllers;
using SDA_PROJ.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class Donors : Form
    {
        DonorController dc;
        HospitalController hc;
        RegStaffDonorController rcd;
        int index;
        string name;
        public Donors(string name)
        {
            this.name = name;
            dc = new DonorController();
            hc = new HospitalController();
            rcd = new RegStaffDonorController();
            InitializeComponent();
            donorBloodType.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
            insert.BackColor = Color.FromArgb(120, 0, 0, 0);
            update.BackColor = Color.FromArgb(120, 0, 0, 0);
            delete.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public Donors()
        {
            dc = new DonorController();
            hc = new HospitalController();
            rcd = new RegStaffDonorController();
            InitializeComponent();
            donorBloodType.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
            insert.BackColor = Color.FromArgb(120, 0, 0, 0);
            update.BackColor = Color.FromArgb(120, 0, 0, 0);
            delete.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void Donors_Load(object sender, EventArgs e)
        {
            DataTable dt= dc.getDonors();
            dataGridView1.DataSource = dt;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }
        private void openNewForm()
        {
            Application.Run(new Dashboard());
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void insert_Click(object sender, EventArgs e)
        {
            Donor obj = new Donor();
            obj.hospital = int.Parse(hospital.Text.ToString());
            obj.name = donorName.Text.ToString();
            obj.bloodgroup = bloodgroup.Text.ToString();
            obj.bloodtype = type.Text.ToString();
            obj.quantity = int.Parse(quantity.Text.ToString());
            obj.contactno = Contact.Text.ToString();
            obj.CNIC = cnic.Text.ToString();
            obj.city = donorCity.Text.ToString();
            obj.date = date.Text.ToString();
            dc.InsertDonor(obj);
            Donors_Load(sender, e);
        }

        private void update_Click(object sender, EventArgs e)
        {
            Donor obj = new Donor();
            int id = int.Parse(dataGridView1.Rows[index].Cells["Donar_ID"].Value.ToString());
            obj.name = dataGridView1.Rows[index].Cells["D_Name"].Value.ToString();
            obj.bloodgroup = dataGridView1.Rows[index].Cells["D_BloogGroup"].Value.ToString();
            obj.bloodtype = dataGridView1.Rows[index].Cells["D_BloodType"].Value.ToString();
            obj.contactno = dataGridView1.Rows[index].Cells["D_ContactNo"].Value.ToString();
            obj.CNIC = dataGridView1.Rows[index].Cells["D_CNIC"].Value.ToString();
            obj.city = dataGridView1.Rows[index].Cells["D_city"].Value.ToString();
            obj.date = dataGridView1.Rows[index].Cells["Date"].Value.ToString();
            obj.quantity = int.Parse(dataGridView1.Rows[index].Cells["D_BloodQuantity"].Value.ToString());
            dc.UpdateDonor(obj, id);
            Donors_Load(sender, e);
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void delete_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dataGridView1.Rows[index].Cells["Donar_ID"].Value.ToString());
            dc.DeleteDonor(id);
            Donors_Load(sender, e);
        }

        private void hospitalData_Click(object sender, EventArgs e)
        {
            Hospital obj = new Hospital();
            obj.ID = int.Parse(dataGridView1.Rows[index].Cells["Donar_ID"].Value.ToString());
            obj.HID = int.Parse(hospital.Text.ToString());
            obj.date = dataGridView1.Rows[index].Cells["Date"].Value.ToString();
            obj.bloodgroup = dataGridView1.Rows[index].Cells["D_BloogGroup"].Value.ToString();
            obj.bloodtype = dataGridView1.Rows[index].Cells["D_BloodType"].Value.ToString();
            obj.quantity = int.Parse(dataGridView1.Rows[index].Cells["D_BloodQuantity"].Value.ToString());
            RegStaffDonor robj = new RegStaffDonor();
            robj.name = this.name;
            robj.DID = int.Parse(dataGridView1.Rows[index].Cells["Donar_ID"].Value.ToString());
            robj.date = dataGridView1.Rows[index].Cells["Date"].Value.ToString();
            rcd.InsertStaff(robj);
            hc.insertdonorHospital(obj);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void donorName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

