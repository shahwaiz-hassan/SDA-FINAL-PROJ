﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class Dashboard : Form
    {
        Thread th;
        string name;
        public Dashboard(string name)
        {
            this.name = name;
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            donors.BackColor = Color.FromArgb(120, 0, 0, 0);
            receivers.BackColor = Color.FromArgb(120, 0, 0, 0);
            hospitals.BackColor = Color.FromArgb(120, 0, 0, 0);
            assignDonor.BackColor = Color.FromArgb(120, 0, 0, 0);
            regStaff.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public Dashboard()
        {
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            donors.BackColor = Color.FromArgb(120, 0, 0, 0);
            receivers.BackColor = Color.FromArgb(120, 0, 0, 0);
            hospitals.BackColor = Color.FromArgb(120, 0, 0, 0);
            assignDonor.BackColor = Color.FromArgb(120, 0, 0, 0);
            regStaff.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void donors_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Donors(this.name).ShowDialog();
            this.Close();
        }
        

        private void receivers_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Receivers(this.name).ShowDialog();
            this.Close();
        }
        private void openReceivers()
        {
            Application.Run(new Receivers());
        }

        private void hospitals_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Hospitals(name).ShowDialog();
            this.Close();
        }
        private void openHospitals()
        {
            Application.Run(new Hospitals());
        }

        private void bloodColl_Click(object sender, EventArgs e)
        {
            th = new Thread(openbloodColl);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
            this.Close();
        }
        private void openbloodColl()
        {
            Application.Run(new AssignDonor());
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void regStaff_Click(object sender, EventArgs e)
        {
            this.Hide();
            new regStaff(name).ShowDialog();
            this.Close();
        }
        private void openRegStaff()
        {
            Application.Run(new regStaff());
        }

        private void assigned_Click(object sender, EventArgs e)
        {
            this.Hide();
            new donorAssigned(this.name).ShowDialog();
            this.Close();
        }

        private void assignDonor_Click(object sender, EventArgs e)
        {
            this.Hide();

            new AssignDonor(this.name).ShowDialog();
            this.Close();
        }

        private void btnCheckLog_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Logs().ShowDialog();
            this.Close();
        }
    }
}
