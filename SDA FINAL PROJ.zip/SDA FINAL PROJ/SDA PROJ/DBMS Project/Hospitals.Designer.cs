﻿namespace SDA_PROJ
{
    partial class Hospitals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.back = new System.Windows.Forms.Button();
            this.viewrHospital = new System.Windows.Forms.Button();
            this.viewdHospital = new System.Windows.Forms.Button();
            this.viewhospitals = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::SDA_PROJ.Properties.Resources.Resized;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(731, 537);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.back);
            this.panel2.Controls.Add(this.viewrHospital);
            this.panel2.Controls.Add(this.viewdHospital);
            this.panel2.Controls.Add(this.viewhospitals);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(731, 537);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.Transparent;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.ForeColor = System.Drawing.SystemColors.Control;
            this.back.Location = new System.Drawing.Point(45, 29);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 7;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // viewrHospital
            // 
            this.viewrHospital.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewrHospital.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewrHospital.ForeColor = System.Drawing.SystemColors.Control;
            this.viewrHospital.Location = new System.Drawing.Point(196, 356);
            this.viewrHospital.Name = "viewrHospital";
            this.viewrHospital.Size = new System.Drawing.Size(338, 65);
            this.viewrHospital.TabIndex = 6;
            this.viewrHospital.Text = "View Receiver Hospitals";
            this.viewrHospital.UseVisualStyleBackColor = true;
            this.viewrHospital.Click += new System.EventHandler(this.viewrHospital_Click);
            // 
            // viewdHospital
            // 
            this.viewdHospital.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewdHospital.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewdHospital.ForeColor = System.Drawing.SystemColors.Control;
            this.viewdHospital.Location = new System.Drawing.Point(196, 239);
            this.viewdHospital.Name = "viewdHospital";
            this.viewdHospital.Size = new System.Drawing.Size(338, 63);
            this.viewdHospital.TabIndex = 5;
            this.viewdHospital.Text = "View Donor Hospitals";
            this.viewdHospital.UseVisualStyleBackColor = true;
            this.viewdHospital.Click += new System.EventHandler(this.viewdHospital_Click);
            // 
            // viewhospitals
            // 
            this.viewhospitals.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewhospitals.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewhospitals.ForeColor = System.Drawing.SystemColors.Control;
            this.viewhospitals.Location = new System.Drawing.Point(196, 118);
            this.viewhospitals.Name = "viewhospitals";
            this.viewhospitals.Size = new System.Drawing.Size(338, 63);
            this.viewhospitals.TabIndex = 4;
            this.viewhospitals.Text = "View Hospitals";
            this.viewhospitals.UseVisualStyleBackColor = true;
            this.viewhospitals.Click += new System.EventHandler(this.viewhospitals_Click);
            // 
            // Hospitals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 533);
            this.Controls.Add(this.panel1);
            this.Name = "Hospitals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hospitals";
            this.Load += new System.EventHandler(this.Hospitals_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button viewrHospital;
        private System.Windows.Forms.Button viewdHospital;
        private System.Windows.Forms.Button viewhospitals;
        private System.Windows.Forms.Button back;
    }
}