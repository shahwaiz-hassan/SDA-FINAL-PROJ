﻿namespace SDA_PROJ
{
    partial class Donors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.donorBloodType = new System.Windows.Forms.Panel();
            this.hospitalData = new System.Windows.Forms.Button();
            this.type = new System.Windows.Forms.ComboBox();
            this.bloodgroup = new System.Windows.Forms.ComboBox();
            this.date = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.hospital = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.delete = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.insert = new System.Windows.Forms.Button();
            this.donorCity = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.cnic = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Contact = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.donorName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.donorBloodType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.BackgroundImage = global::SDA_PROJ.Properties.Resources.Resized;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.donorBloodType);
            this.panel1.Location = new System.Drawing.Point(-3, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 592);
            this.panel1.TabIndex = 0;
            // 
            // donorBloodType
            // 
            this.donorBloodType.BackColor = System.Drawing.Color.DimGray;
            this.donorBloodType.Controls.Add(this.hospitalData);
            this.donorBloodType.Controls.Add(this.type);
            this.donorBloodType.Controls.Add(this.bloodgroup);
            this.donorBloodType.Controls.Add(this.date);
            this.donorBloodType.Controls.Add(this.label9);
            this.donorBloodType.Controls.Add(this.hospital);
            this.donorBloodType.Controls.Add(this.label7);
            this.donorBloodType.Controls.Add(this.dataGridView1);
            this.donorBloodType.Controls.Add(this.delete);
            this.donorBloodType.Controls.Add(this.update);
            this.donorBloodType.Controls.Add(this.insert);
            this.donorBloodType.Controls.Add(this.donorCity);
            this.donorBloodType.Controls.Add(this.label8);
            this.donorBloodType.Controls.Add(this.quantity);
            this.donorBloodType.Controls.Add(this.label);
            this.donorBloodType.Controls.Add(this.cnic);
            this.donorBloodType.Controls.Add(this.label6);
            this.donorBloodType.Controls.Add(this.Contact);
            this.donorBloodType.Controls.Add(this.label5);
            this.donorBloodType.Controls.Add(this.label4);
            this.donorBloodType.Controls.Add(this.label3);
            this.donorBloodType.Controls.Add(this.back);
            this.donorBloodType.Controls.Add(this.donorName);
            this.donorBloodType.Controls.Add(this.label2);
            this.donorBloodType.Controls.Add(this.label1);
            this.donorBloodType.Cursor = System.Windows.Forms.Cursors.Default;
            this.donorBloodType.Location = new System.Drawing.Point(0, 0);
            this.donorBloodType.Name = "donorBloodType";
            this.donorBloodType.Size = new System.Drawing.Size(775, 592);
            this.donorBloodType.TabIndex = 0;
            this.donorBloodType.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // hospitalData
            // 
            this.hospitalData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.hospitalData.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitalData.ForeColor = System.Drawing.SystemColors.Control;
            this.hospitalData.Location = new System.Drawing.Point(470, 270);
            this.hospitalData.Name = "hospitalData";
            this.hospitalData.Size = new System.Drawing.Size(260, 33);
            this.hospitalData.TabIndex = 30;
            this.hospitalData.Text = "ADD DATA IN HOSPITAL";
            this.hospitalData.UseVisualStyleBackColor = true;
            this.hospitalData.Click += new System.EventHandler(this.hospitalData_Click);
            // 
            // type
            // 
            this.type.FormattingEnabled = true;
            this.type.Items.AddRange(new object[] {
            "+",
            "-"});
            this.type.Location = new System.Drawing.Point(193, 161);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(187, 21);
            this.type.TabIndex = 29;
            this.type.Text = "Select";
            // 
            // bloodgroup
            // 
            this.bloodgroup.FormattingEnabled = true;
            this.bloodgroup.Items.AddRange(new object[] {
            "A",
            "B",
            "AB",
            "O"});
            this.bloodgroup.Location = new System.Drawing.Point(193, 121);
            this.bloodgroup.Name = "bloodgroup";
            this.bloodgroup.Size = new System.Drawing.Size(186, 21);
            this.bloodgroup.TabIndex = 28;
            this.bloodgroup.Text = "Select";
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(193, 233);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(187, 20);
            this.date.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(30, 233);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 17);
            this.label9.TabIndex = 26;
            this.label9.Text = "Date:";
            // 
            // hospital
            // 
            this.hospital.Location = new System.Drawing.Point(517, 200);
            this.hospital.Name = "hospital";
            this.hospital.Size = new System.Drawing.Size(187, 20);
            this.hospital.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(423, 203);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 17);
            this.label7.TabIndex = 24;
            this.label7.Text = "Hospital ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 322);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(712, 244);
            this.dataGridView1.TabIndex = 21;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellValueChanged);
            // 
            // delete
            // 
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.ForeColor = System.Drawing.SystemColors.Control;
            this.delete.Location = new System.Drawing.Point(329, 270);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(113, 33);
            this.delete.TabIndex = 20;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // update
            // 
            this.update.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.update.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.ForeColor = System.Drawing.SystemColors.Control;
            this.update.Location = new System.Drawing.Point(193, 270);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(113, 33);
            this.update.TabIndex = 19;
            this.update.Text = "UPDATE";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // insert
            // 
            this.insert.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.insert.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insert.ForeColor = System.Drawing.SystemColors.Control;
            this.insert.Location = new System.Drawing.Point(52, 270);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(113, 33);
            this.insert.TabIndex = 18;
            this.insert.Text = "INSERT";
            this.insert.UseVisualStyleBackColor = true;
            this.insert.Click += new System.EventHandler(this.insert_Click);
            // 
            // donorCity
            // 
            this.donorCity.Location = new System.Drawing.Point(193, 200);
            this.donorCity.Name = "donorCity";
            this.donorCity.Size = new System.Drawing.Size(186, 20);
            this.donorCity.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(29, 200);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Donor city:";
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(517, 162);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(186, 20);
            this.quantity.TabIndex = 13;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.SystemColors.Control;
            this.label.Location = new System.Drawing.Point(426, 162);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(79, 17);
            this.label.TabIndex = 12;
            this.label.Text = "Quantity:";
            // 
            // cnic
            // 
            this.cnic.Location = new System.Drawing.Point(517, 124);
            this.cnic.Name = "cnic";
            this.cnic.Size = new System.Drawing.Size(186, 20);
            this.cnic.TabIndex = 11;
            this.cnic.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(426, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "CNIC:";
            // 
            // Contact
            // 
            this.Contact.Location = new System.Drawing.Point(517, 82);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(186, 20);
            this.Contact.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(426, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Contact:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(29, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Donor blood type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(29, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Donor blood group:";
            // 
            // back
            // 
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.ForeColor = System.Drawing.SystemColors.Control;
            this.back.Location = new System.Drawing.Point(32, 29);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 3;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // donorName
            // 
            this.donorName.Location = new System.Drawing.Point(193, 82);
            this.donorName.Name = "donorName";
            this.donorName.Size = new System.Drawing.Size(186, 20);
            this.donorName.TabIndex = 2;
            this.donorName.TextChanged += new System.EventHandler(this.donorName_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(29, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Donor name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(284, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "DONOR DATA";
            // 
            // Donors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 589);
            this.Controls.Add(this.panel1);
            this.Name = "Donors";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Donors";
            this.Load += new System.EventHandler(this.Donors_Load);
            this.panel1.ResumeLayout(false);
            this.donorBloodType.ResumeLayout(false);
            this.donorBloodType.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel donorBloodType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.TextBox donorName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Contact;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox cnic;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox quantity;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.TextBox donorCity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox hospital;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox date;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox type;
        private System.Windows.Forms.ComboBox bloodgroup;
        private System.Windows.Forms.Button hospitalData;
    }
}