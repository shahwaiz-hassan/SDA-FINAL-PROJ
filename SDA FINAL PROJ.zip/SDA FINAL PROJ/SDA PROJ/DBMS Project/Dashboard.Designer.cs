﻿namespace SDA_PROJ
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCheckLog = new System.Windows.Forms.Button();
            this.assigned = new System.Windows.Forms.Button();
            this.regStaff = new System.Windows.Forms.Button();
            this.assignDonor = new System.Windows.Forms.Button();
            this.hospitals = new System.Windows.Forms.Button();
            this.receivers = new System.Windows.Forms.Button();
            this.donors = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-1, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(757, 641);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.btnCheckLog);
            this.panel2.Controls.Add(this.assigned);
            this.panel2.Controls.Add(this.regStaff);
            this.panel2.Controls.Add(this.assignDonor);
            this.panel2.Controls.Add(this.hospitals);
            this.panel2.Controls.Add(this.receivers);
            this.panel2.Controls.Add(this.donors);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(757, 638);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnCheckLog
            // 
            this.btnCheckLog.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCheckLog.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckLog.ForeColor = System.Drawing.SystemColors.Control;
            this.btnCheckLog.Location = new System.Drawing.Point(203, 565);
            this.btnCheckLog.Name = "btnCheckLog";
            this.btnCheckLog.Size = new System.Drawing.Size(338, 60);
            this.btnCheckLog.TabIndex = 6;
            this.btnCheckLog.Text = "Check Logs";
            this.btnCheckLog.UseVisualStyleBackColor = true;
            this.btnCheckLog.Click += new System.EventHandler(this.btnCheckLog_Click);
            // 
            // assigned
            // 
            this.assigned.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.assigned.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assigned.ForeColor = System.Drawing.SystemColors.Control;
            this.assigned.Location = new System.Drawing.Point(203, 197);
            this.assigned.Name = "assigned";
            this.assigned.Size = new System.Drawing.Size(338, 60);
            this.assigned.TabIndex = 5;
            this.assigned.Text = "Assigned";
            this.assigned.UseVisualStyleBackColor = true;
            this.assigned.Click += new System.EventHandler(this.assigned_Click);
            // 
            // regStaff
            // 
            this.regStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.regStaff.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regStaff.ForeColor = System.Drawing.SystemColors.Control;
            this.regStaff.Location = new System.Drawing.Point(203, 477);
            this.regStaff.Name = "regStaff";
            this.regStaff.Size = new System.Drawing.Size(338, 60);
            this.regStaff.TabIndex = 4;
            this.regStaff.Text = "Registration Staff";
            this.regStaff.UseVisualStyleBackColor = true;
            this.regStaff.Click += new System.EventHandler(this.regStaff_Click);
            // 
            // assignDonor
            // 
            this.assignDonor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.assignDonor.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assignDonor.ForeColor = System.Drawing.SystemColors.Control;
            this.assignDonor.Location = new System.Drawing.Point(203, 383);
            this.assignDonor.Name = "assignDonor";
            this.assignDonor.Size = new System.Drawing.Size(338, 60);
            this.assignDonor.TabIndex = 3;
            this.assignDonor.Text = "Assign Donor to Receiver";
            this.assignDonor.UseVisualStyleBackColor = true;
            this.assignDonor.Click += new System.EventHandler(this.assignDonor_Click);
            // 
            // hospitals
            // 
            this.hospitals.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.hospitals.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitals.ForeColor = System.Drawing.SystemColors.Control;
            this.hospitals.Location = new System.Drawing.Point(203, 291);
            this.hospitals.Name = "hospitals";
            this.hospitals.Size = new System.Drawing.Size(338, 58);
            this.hospitals.TabIndex = 2;
            this.hospitals.Text = "Hospitals";
            this.hospitals.UseVisualStyleBackColor = true;
            this.hospitals.Click += new System.EventHandler(this.hospitals_Click);
            // 
            // receivers
            // 
            this.receivers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.receivers.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.receivers.ForeColor = System.Drawing.SystemColors.Control;
            this.receivers.Location = new System.Drawing.Point(203, 104);
            this.receivers.Name = "receivers";
            this.receivers.Size = new System.Drawing.Size(338, 56);
            this.receivers.TabIndex = 1;
            this.receivers.Text = "Receivers";
            this.receivers.UseVisualStyleBackColor = true;
            this.receivers.Click += new System.EventHandler(this.receivers_Click);
            // 
            // donors
            // 
            this.donors.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.donors.Font = new System.Drawing.Font("Lucida Fax", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.donors.ForeColor = System.Drawing.SystemColors.Control;
            this.donors.Location = new System.Drawing.Point(203, 13);
            this.donors.Name = "donors";
            this.donors.Size = new System.Drawing.Size(338, 56);
            this.donors.TabIndex = 0;
            this.donors.Text = "Donors";
            this.donors.UseVisualStyleBackColor = true;
            this.donors.Click += new System.EventHandler(this.donors_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 634);
            this.Controls.Add(this.panel1);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button donors;
        private System.Windows.Forms.Button receivers;
        private System.Windows.Forms.Button hospitals;
        private System.Windows.Forms.Button assignDonor;
        private System.Windows.Forms.Button regStaff;
        private System.Windows.Forms.Button assigned;
        private System.Windows.Forms.Button btnCheckLog;
    }
}