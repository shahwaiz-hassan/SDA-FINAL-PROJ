﻿using SDA_PROJ.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class donorAssigned : Form
    {
        DonorAssignController dac;
        string name;
        public donorAssigned(string name)
        {
            this.name = name;
            dac = new DonorAssignController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public donorAssigned()
        {
            dac = new DonorAssignController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }

        private void donorAssigned_Load(object sender, EventArgs e)
        {
            DataTable dt = dac.GetData();
            dataGridView1.DataSource = dt;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
