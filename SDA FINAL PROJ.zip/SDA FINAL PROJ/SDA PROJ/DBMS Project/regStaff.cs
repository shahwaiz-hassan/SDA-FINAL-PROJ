﻿using SDA_PROJ.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class regStaff : Form
    {
        RegStaffDonorController rcd;
        RegStaffReceiverController rcr;
        string name;
        public regStaff(string name)
        {
            this.name = name;
            rcr = new RegStaffReceiverController();
            rcd = new RegStaffDonorController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public regStaff()
        {
            rcr = new RegStaffReceiverController();
            rcd = new RegStaffDonorController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }
            private void opennewform()
            {
                Application.Run(new Dashboard());
            }

        private void regStaff_Load(object sender, EventArgs e)
        {
            DataTable dt = rcd.getStaff();
            dataGridView1.DataSource = dt;
            DataTable dt1 = rcr.getStaff();
            dataGridView2.DataSource = dt1;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }

