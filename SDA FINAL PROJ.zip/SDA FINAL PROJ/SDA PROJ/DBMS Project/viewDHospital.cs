﻿using SDA_PROJ.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class viewDHospital : Form
    {
        HospitalController hc;
        string name;
        public viewDHospital(string name)
        {
            this.name = name;
            hc = new HospitalController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public viewDHospital()
        {
            hc = new HospitalController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Hospitals(name).ShowDialog();
            this.Close();
        }
        private void opennewform()
        {
            Application.Run(new Hospitals());
        }

        private void viewDHospital_Load(object sender, EventArgs e)
        {
            DataTable dt = hc.DonorHospital();
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
