﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class Logs : Form
    {
        DatabaseHelper db;
        string name;
        public Logs(string name)
        {
            this.name = name;
            db = new DatabaseHelper();
            InitializeComponent();
        }
        public Logs()
        {
            db = new DatabaseHelper();
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }

        private void Logs_Load(object sender, EventArgs e)
        {
            string q1 = "select * from DonorLog";
            string q2 = "select * from ReceiverLog";
            DataTable dtd = db.Read(q1);
            DataTable dtr = db.Read(q2);
            dataGridView1.DataSource = dtd;
            dataGridView2.DataSource = dtr;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
