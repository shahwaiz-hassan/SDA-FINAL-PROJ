﻿using SDA_PROJ.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDA_PROJ.Controllers
{
    class RegStaffDonorController
    {
        DatabaseHelper db;
        public RegStaffDonorController()
        {
            db = new DatabaseHelper();
        }
        public void InsertStaff(RegStaffDonor obj)
        {
            string query = "insert into Registration_staff_Donar values('" + obj.name + "'," + obj.DID + ",'" + obj.date + "')";
            db.InsertUpdateDelete(query);
        }
        public DataTable getStaff()
        {
            string query = "select * from Registration_staff_Donar";
            return db.Read(query);
        }
    }
}
