﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SDA_PROJ.Models;
using SDA_PROJ.Controllers;
using System.Data;

namespace SDA_PROJ.Controllers
{
    class RegStaffReceiverController
    {
        DatabaseHelper db;
        public RegStaffReceiverController()
        {
            db = new DatabaseHelper();
        }
        public void InsertStaff(RegStaffReceiver obj)
        {
            string query = "insert into Registration_staff_reciever values('" + obj.name + "'," + obj.DID + ",'" + obj.date + "')";
            db.InsertUpdateDelete(query);
        }
        public DataTable getStaff()
        {
            string query = "select * from Registration_staff_reciever";
            return db.Read(query);
        }
    }
}
