﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using SDA_PROJ.Models;
using System.Windows.Forms;

namespace SDA_PROJ.Controllers
{
    class ReceiverController
    {
        string query;
        DatabaseHelper db;
        public ReceiverController()
        {
            db = new DatabaseHelper();
        }
        public DataTable getReceivers()
        {
            query = "select * from Reciever";
            return db.Read(query);
        }
        public void InsertReceiver(Receiver obj)
        {

            //query = "insert into Reciever values('" + obj.name + "','" + obj.bloodgroup + "','" + obj.bloodtype + "','" + obj.contactno + "','" + obj.CNIC + "','" + obj.city + "','" + obj.date + "','" + obj.quantity + "')";
            query = "insert into Reciever values('" + obj.hos + "','" + obj.name + "','" + obj.bloodgroup + "','" + obj.bloodtype + "','" + obj.contactno + "','" + obj.CNIC + "','" + obj.quantity + "','" + obj.city + "','" + obj.date + "')";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data inserted successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
        public void UpdateReceiver(Receiver obj, int id)
        {
            query = "update Reciever set R_Name='" + obj.name + "',R_BloogGroup='" + obj.bloodgroup + "',R_BloodType='" + obj.bloodtype + "',R_ContactNo='" + obj.contactno + "',R_CNIC='" + obj.CNIC + "',R_city='" + obj.city + "',[Date]='" + obj.date + "',R_BloodQuantity='" + obj.quantity + "' where Reciever_ID=" + id + "";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data updated successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
        public void DeleteReceiver(int id)
        {
            query = "delete from Reciever where Reciever_ID=" + id + "";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data deleted successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
    }
}
