﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SDA_PROJ.Models;
using System.Windows.Forms;

namespace SDA_PROJ.Controllers
{
    class HospitalController
    {
        DatabaseHelper db;
        string query;
        public HospitalController()
        {
            db = new DatabaseHelper();
        }
        public DataTable Hospitals()
        {
            query = "select * from Hospital";
            return db.Read(query);
        }
        public void insertdonorHospital(Hospital obj)
        {
            query = "insert into Donar_Hospital values(" + obj.ID + "," + obj.HID + ",'" + obj.date + "','" + obj.bloodgroup + "','" + obj.bloodtype + "'," + obj.quantity + ")";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data added successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
        public DataTable DonorHospital()
        {
            query = "select * from Donar_Hospital";
            return db.Read(query);
        }
        public DataTable ReceiverHospital()
        {
            query = "select * from Reciever_Hospital";
            return db.Read(query);
        }
        public void insertreceiverHospital(Hospital obj)
        {
            query = "insert into Reciever_Hospital values(" + obj.ID + "," + obj.HID + ",'" + obj.date + "','" + obj.bloodgroup + "','" + obj.bloodtype + "'," + obj.quantity + ")";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data added successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
    }
}
