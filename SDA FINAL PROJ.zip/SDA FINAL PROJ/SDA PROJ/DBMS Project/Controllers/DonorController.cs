﻿using SDA_PROJ.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ.Controllers
{
    class DonorController
    {
        string query;
        DatabaseHelper db;
        public DonorController()
        {
            db = new DatabaseHelper();
        }
        public DataTable getDonors()
        {
            query = "select * from Donar";
            return db.Read(query);
        }
        public void InsertDonor(Donor obj)
        {
            try
            {
                query = "insert into Donar values('" + obj.hospital + "','" + obj.name + "','" + obj.bloodgroup + "','" + obj.bloodtype + "','" + obj.quantity + "','" + obj.contactno + "','" + obj.CNIC + "','" + obj.city + "','" + obj.date + "')";

                //query = "insert into Donar values('" + obj.name + "','" + obj.bloodgroup + "','" + obj.bloodtype + "','" + obj.contactno + "','" + obj.CNIC + "','" + obj.city + "','" + obj.date + "','" + obj.quantity + "')";
                if (db.InsertUpdateDelete(query))
                {
                    MessageBox.Show("Data inserted successfully");
                }
                else
                {
                    MessageBox.Show("An error occured");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }

        }
        public void UpdateDonor(Donor obj,int id)
        {
            query = "update Donar set D_Name='" + obj.name + "',D_BloogGroup='" + obj.bloodgroup + "',D_BloodType='" + obj.bloodtype + "',D_BloodQuantity='" + obj.quantity + "',D_ContactNo='" + obj.contactno + "',D_CNIC='" + obj.CNIC + "',D_city='" + obj.city + "',Date='" + obj.date + "' where Donar_ID=" + id + "";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data updated successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
        public void DeleteDonor(int id)
        {
            query = "delete from Donar where Donar_ID=" + id + "";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Data deleted successfully");
            }
            else
            {
                MessageBox.Show("An error occured");
            }
        }
    }
}
