﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDA_PROJ.Models;

namespace SDA_PROJ.Controllers
{
    class DonorAssignController
    {
        DatabaseHelper db;
        string query;
        public DonorAssignController()
        {
            db = new DatabaseHelper();
        }
        public DataTable GetData()
        {
            query = "select * from Donar_Assign";
            return db.Read(query);
        }
        public void InsertData(AssignDonorModel obj)
        {
            query = "insert into Donar_Assign values(" + obj.RID + "," + obj.DID + ",'" + obj.date + "','" + obj.dbg + "','" + obj.dbt + "','" + obj.rbg + "','" + obj.rbt + "')";
            if (db.InsertUpdateDelete(query))
            {
                MessageBox.Show("Donor Assigned Successfully");
            }
            else
            {
                MessageBox.Show("An error Occured");
            }
        }
    }
}
