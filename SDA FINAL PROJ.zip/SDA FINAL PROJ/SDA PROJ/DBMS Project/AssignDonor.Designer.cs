﻿namespace SDA_PROJ
{
    partial class AssignDonor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAssign = new System.Windows.Forms.Button();
            this.date = new System.Windows.Forms.TextBox();
            this.receiverbloodtype = new System.Windows.Forms.ComboBox();
            this.receiverbloodgroup = new System.Windows.Forms.ComboBox();
            this.recieverid = new System.Windows.Forms.ComboBox();
            this.donorbloodtype = new System.Windows.Forms.ComboBox();
            this.donorbloodgroup = new System.Windows.Forms.ComboBox();
            this.donorid = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::SDA_PROJ.Properties.Resources.Resized;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-41, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(712, 545);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.btnAssign);
            this.panel2.Controls.Add(this.date);
            this.panel2.Controls.Add(this.receiverbloodtype);
            this.panel2.Controls.Add(this.receiverbloodgroup);
            this.panel2.Controls.Add(this.recieverid);
            this.panel2.Controls.Add(this.donorbloodtype);
            this.panel2.Controls.Add(this.donorbloodgroup);
            this.panel2.Controls.Add(this.donorid);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.back);
            this.panel2.Location = new System.Drawing.Point(38, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(671, 545);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnAssign
            // 
            this.btnAssign.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAssign.Font = new System.Drawing.Font("Lucida Fax", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssign.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAssign.Location = new System.Drawing.Point(518, 203);
            this.btnAssign.Name = "btnAssign";
            this.btnAssign.Size = new System.Drawing.Size(84, 33);
            this.btnAssign.TabIndex = 30;
            this.btnAssign.Text = "ASSIGN";
            this.btnAssign.UseVisualStyleBackColor = true;
            this.btnAssign.Click += new System.EventHandler(this.btnAssign_Click);
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(231, 205);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(100, 20);
            this.date.TabIndex = 29;
            // 
            // receiverbloodtype
            // 
            this.receiverbloodtype.FormattingEnabled = true;
            this.receiverbloodtype.Location = new System.Drawing.Point(518, 165);
            this.receiverbloodtype.Name = "receiverbloodtype";
            this.receiverbloodtype.Size = new System.Drawing.Size(84, 21);
            this.receiverbloodtype.TabIndex = 28;
            this.receiverbloodtype.Text = "Select";
            // 
            // receiverbloodgroup
            // 
            this.receiverbloodgroup.FormattingEnabled = true;
            this.receiverbloodgroup.Location = new System.Drawing.Point(518, 131);
            this.receiverbloodgroup.Name = "receiverbloodgroup";
            this.receiverbloodgroup.Size = new System.Drawing.Size(84, 21);
            this.receiverbloodgroup.TabIndex = 27;
            this.receiverbloodgroup.Text = "Select";
            // 
            // recieverid
            // 
            this.recieverid.FormattingEnabled = true;
            this.recieverid.Location = new System.Drawing.Point(518, 93);
            this.recieverid.Name = "recieverid";
            this.recieverid.Size = new System.Drawing.Size(84, 21);
            this.recieverid.TabIndex = 26;
            this.recieverid.Text = "Select";
            // 
            // donorbloodtype
            // 
            this.donorbloodtype.FormattingEnabled = true;
            this.donorbloodtype.Location = new System.Drawing.Point(231, 165);
            this.donorbloodtype.Name = "donorbloodtype";
            this.donorbloodtype.Size = new System.Drawing.Size(84, 21);
            this.donorbloodtype.TabIndex = 25;
            this.donorbloodtype.Text = "Select";
            // 
            // donorbloodgroup
            // 
            this.donorbloodgroup.FormattingEnabled = true;
            this.donorbloodgroup.Location = new System.Drawing.Point(231, 131);
            this.donorbloodgroup.Name = "donorbloodgroup";
            this.donorbloodgroup.Size = new System.Drawing.Size(84, 21);
            this.donorbloodgroup.TabIndex = 24;
            this.donorbloodgroup.Text = "Select";
            // 
            // donorid
            // 
            this.donorid.FormattingEnabled = true;
            this.donorid.Location = new System.Drawing.Point(231, 93);
            this.donorid.Name = "donorid";
            this.donorid.Size = new System.Drawing.Size(84, 21);
            this.donorid.TabIndex = 23;
            this.donorid.Text = "Select";
            this.donorid.SelectedIndexChanged += new System.EventHandler(this.donorid_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(66, 205);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 18);
            this.label8.TabIndex = 22;
            this.label8.Text = "Date:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(330, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 18);
            this.label7.TabIndex = 21;
            this.label7.Text = "Receiver Bloodtype:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(66, 168);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 18);
            this.label6.TabIndex = 20;
            this.label6.Text = "Donor Bloodtype:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(330, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 18);
            this.label5.TabIndex = 19;
            this.label5.Text = "Receiver Bloodgroup:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(66, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 18);
            this.label4.TabIndex = 18;
            this.label4.Text = "Donor Bloodgroup:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(330, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 18);
            this.label3.TabIndex = 17;
            this.label3.Text = "Receiver ID:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(66, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "Donor ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(69, 261);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(533, 251);
            this.dataGridView1.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(168, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(414, 32);
            this.label1.TabIndex = 14;
            this.label1.Text = "ASSIGN DONOR TO RECEIVER";
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.Transparent;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.ForeColor = System.Drawing.SystemColors.Control;
            this.back.Location = new System.Drawing.Point(50, 40);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 12;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // AssignDonor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 542);
            this.Controls.Add(this.panel1);
            this.Name = "AssignDonor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BloodColl";
            this.Load += new System.EventHandler(this.AssignDonor_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnAssign;
        private System.Windows.Forms.TextBox date;
        private System.Windows.Forms.ComboBox receiverbloodtype;
        private System.Windows.Forms.ComboBox receiverbloodgroup;
        private System.Windows.Forms.ComboBox recieverid;
        private System.Windows.Forms.ComboBox donorbloodtype;
        private System.Windows.Forms.ComboBox donorbloodgroup;
        private System.Windows.Forms.ComboBox donorid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}