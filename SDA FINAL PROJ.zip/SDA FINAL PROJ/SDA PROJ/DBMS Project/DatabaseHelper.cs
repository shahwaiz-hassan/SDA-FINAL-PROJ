﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SDA_PROJ
{
    class DatabaseHelper
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        public DatabaseHelper()
        {
            string connectionString = @"Data Source=LAPTOP-HNGBSOUQ\SQLEXPRESS;Initial Catalog=Blood_Bank;Integrated Security=True";
            con = new SqlConnection(connectionString);
        }
        public bool InsertUpdateDelete(string query)
        {
            cmd = new SqlCommand(query, con);
            con.Open();
            int count = cmd.ExecuteNonQuery();
            if (count > 0)
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }
        public DataTable Read(string query)
        {
            cmd = new SqlCommand(query, con);
            sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return dt;
            }
            else return new DataTable();
        }
    }
}
