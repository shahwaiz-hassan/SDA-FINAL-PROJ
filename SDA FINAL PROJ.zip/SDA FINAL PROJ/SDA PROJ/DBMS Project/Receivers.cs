﻿using SDA_PROJ.Controllers;
using SDA_PROJ.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PROJ
{
    public partial class Receivers : Form
    {
        ReceiverController rc;
        HospitalController hc;
        RegStaffReceiverController rcr;
        int index;
        string name;
        public Receivers(string name)
        {
            this.name = name;
            hc = new HospitalController();
            rc = new ReceiverController();
            rcr = new RegStaffReceiverController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }
        public Receivers()
        {
            hc = new HospitalController();
            rc = new ReceiverController();
            rcr = new RegStaffReceiverController();
            InitializeComponent();
            panel2.BackColor = Color.FromArgb(120, 0, 0, 0);
            back.BackColor = Color.FromArgb(120, 0, 0, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Dashboard(name).ShowDialog();
            this.Close();
        }
        private void openNewForm()
        {
            Application.Run(new Dashboard());
        }

        private void Receivers_Load(object sender, EventArgs e)
        {
            DataTable dt = rc.getReceivers();
            dataGridView1.DataSource = dt;
        }

        private void insert_Click(object sender, EventArgs e)
        {
            Receiver obj = new Receiver();
            obj.hos = int.Parse(hid.Text.ToString());
            obj.name = receiverName.Text.ToString();
            obj.bloodgroup = bloodgroup.Text.ToString();
            obj.bloodtype = type.Text.ToString();
            obj.contactno = Contact.Text.ToString();
            obj.CNIC = cnic.Text.ToString();
            obj.quantity = int.Parse(quantity.Text.ToString());
            obj.city = receiverCity.Text.ToString();
            obj.date = txtdate.Text.ToString();
            rc.InsertReceiver(obj);
            DataTable dt = rc.getReceivers();
            dataGridView1.DataSource = dt;
        }

        private void update_Click(object sender, EventArgs e)
        {
            Receiver obj = new Receiver();
            int id = int.Parse(dataGridView1.Rows[index].Cells["Reciever_ID"].Value.ToString());
            obj.name = dataGridView1.Rows[index].Cells["R_Name"].Value.ToString();
            obj.bloodgroup = dataGridView1.Rows[index].Cells["R_BloogGroup"].Value.ToString();
            obj.bloodtype = dataGridView1.Rows[index].Cells["R_BloodType"].Value.ToString();
            obj.contactno = dataGridView1.Rows[index].Cells["R_ContactNo"].Value.ToString();
            obj.CNIC = dataGridView1.Rows[index].Cells["R_CNIC"].Value.ToString();
            obj.city = dataGridView1.Rows[index].Cells["R_city"].Value.ToString();
            obj.date = dataGridView1.Rows[index].Cells["Date"].Value.ToString();
            obj.quantity = int.Parse(dataGridView1.Rows[index].Cells["R_BloodQuantity"].Value.ToString());
            rc.UpdateReceiver(obj, id);
            DataTable dt = rc.getReceivers();
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //this.index = e.RowIndex;
        }

        private void delete_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dataGridView1.Rows[index].Cells["Reciever_ID"].Value.ToString());
            rc.DeleteReceiver(id);
            DataTable dt = rc.getReceivers();
            dataGridView1.DataSource = dt;
        }

        private void addhospital_Click(object sender, EventArgs e)
        {
            Hospital obj = new Hospital();
            obj.ID = int.Parse(dataGridView1.Rows[index].Cells["Reciever_ID"].Value.ToString());
            obj.HID = int.Parse(hid.Text.ToString());
            obj.bloodgroup = dataGridView1.Rows[index].Cells["R_BloogGroup"].Value.ToString();
            obj.bloodtype = dataGridView1.Rows[index].Cells["R_BloodType"].Value.ToString();
            obj.date = dataGridView1.Rows[index].Cells["Date"].Value.ToString();
            obj.quantity = int.Parse(dataGridView1.Rows[index].Cells["R_BloodQuantity"].Value.ToString());
            RegStaffReceiver robj = new RegStaffReceiver();
            robj.name = this.name;
            robj.DID = int.Parse(dataGridView1.Rows[index].Cells["Reciever_ID"].Value.ToString());
            robj.date = dataGridView1.Rows[index].Cells["Date"].Value.ToString();
            rcr.InsertStaff(robj);
            hc.insertreceiverHospital(obj);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.index = e.RowIndex;
        }
    }
}
