﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDA_PROJ.Models
{
    class Hospital
    {
        public int ID { get; set; }
        public int HID { get; set; }
        public string date { get; set; }
        public string bloodgroup { get; set; }
        public string bloodtype { get; set; }
        public int quantity { get; set; }
    }
}
