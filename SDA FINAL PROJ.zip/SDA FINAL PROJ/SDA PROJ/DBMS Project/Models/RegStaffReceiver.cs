﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDA_PROJ.Models
{
    class RegStaffReceiver
    {
        public string name { get; set; }
        public int DID { get; set; }
        public string date { get; set; }
    }
}
