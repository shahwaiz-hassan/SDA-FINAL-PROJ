﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDA_PROJ.Models
{
    class Receiver
    {
        public int hos { get; set; }
        public string name { get; set; }
        public string bloodgroup { get; set; }
        public string bloodtype { get; set; }
        public string contactno { get; set; }
        public string CNIC { get; set; }
        public string city { get; set; }
        public string date { get; set; }
        public int quantity { get; set; }
    }
}
