﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDA_PROJ.Models
{
    class AssignDonorModel
    {
        public int DID { get; set; }
        public int RID { get; set; }
        public string dbg { get; set; }
        public string dbt { get; set; }
        public string rbg { get; set; }
        public string rbt { get; set; }
        public string date { get; set; }
    }
}
